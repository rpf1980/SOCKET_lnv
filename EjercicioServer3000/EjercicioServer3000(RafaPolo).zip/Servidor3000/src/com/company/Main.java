package com.company;

import static com.company.Servidor.lanzaServidor;

public class Main {

    public static void main(String[] args)
    {
        lanzaServidor();
    }
}